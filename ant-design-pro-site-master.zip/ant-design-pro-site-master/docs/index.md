---
sidemenu: false
gapless: true
title: Out-of-box UI solution for enterprise applications
legacy: /index
---

<code src="../.dumi/theme/home/index.js" inline></code>
