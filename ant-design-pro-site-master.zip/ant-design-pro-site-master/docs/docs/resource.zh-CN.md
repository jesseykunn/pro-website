---
order: 94
title: 设计资源
group:
  title: 其它
nav:
  title: 文档
  path: /docs
  order: 1
---

Ant Design Pro 配套的设计资源。

## Axure Library <img  class="icon" src="https://zos.alipayobjects.com/rmsportal/qXrCHrsuyrINSeerFOerLcTTFZiEzHAJ.png" width="24" />

Ant Design 3.0 和 Ant Design Pro 的配套 Axure 资源包。

- 链接：http://library.ant.design/

## Ant Design Pro Sketch <img class="icon" src="https://zos.alipayobjects.com/rmsportal/vfxJzCLqZxehgquvQNqX.png" width="24" />

Ant Design Pro 的配套 Sketch 模板。

- 链接：[Ant.Design.Pro.sketch](https://github.com/ant-design/ant-design/releases/download/resource/Ant.Design.Pro.sketch)

## 其他 Ant Design 设计资源

- 链接：https://ant.design/docs/resources-cn
