---
order: 94
title: Design Kit
group:
  title: Other
nav:
  title: Documents
  path: /docs
  order: 1
---

The Resource of Ant Design Pro.

## Axure Library <img src="https://zos.alipayobjects.com/rmsportal/qXrCHrsuyrINSeerFOerLcTTFZiEzHAJ.png" width="24" />

Axure Package for Ant Design 3.0 and Ant Design Pro.

- link: http://library.ant.design/

## Ant Design Pro Sketch <img src="https://zos.alipayobjects.com/rmsportal/vfxJzCLqZxehgquvQNqX.png" width="24" />

Sketch Templates for Ant Design Pro.

- link: [Ant.Design.Pro.sketch](https://github.com/ant-design/ant-design/releases/download/resource/Ant.Design.Pro.sketch)

## Other resources of Ant Design

- link: https://ant.design/docs/resource/download
