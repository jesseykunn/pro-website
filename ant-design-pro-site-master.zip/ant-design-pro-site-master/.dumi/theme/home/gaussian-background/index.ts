export { default as GaussianBackground } from './GaussianBackground';
