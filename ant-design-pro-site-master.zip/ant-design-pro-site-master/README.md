# Ant Design Pro Site

The documentation source of [Ant Design Pro](https://github.com/ant-design/ant-design-pro).

### Development

```bash
git clone git@github.com:ant-design/ant-design-pro-site.git
cd ant-design-pro-site
npm install
npm start
```

Then visit <http://localhost:8000> .

### Deploy

```bash
npm run site
```

### docs

[dumi](https://d.umijs.org/)
