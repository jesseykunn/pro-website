interface Window {
  DarkReader: any;
}
