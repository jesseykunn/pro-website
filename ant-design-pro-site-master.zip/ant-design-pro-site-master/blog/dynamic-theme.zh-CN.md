---
order: 8
title: 黑色主题和动态切换
group:
  title: Blog
  path: /
nav:
  title: Blog
  path: /blog
  order: 3
time: 2019-12-25
---

经过漫长的时间开发（咕咕）之后 Pro 的黑色主题，和新的主题切换方案正式上线了。一图胜千言，直接看图吧。

![image](https://gw.alipayobjects.com/zos/antfincdn/raCkHezMns/Kapture%2525202019-11-25%252520at%25252019.15.12.gif)
