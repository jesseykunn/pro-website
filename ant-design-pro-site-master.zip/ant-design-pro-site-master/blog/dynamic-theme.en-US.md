---
order: 8
title: Black theme and dynamic switching
group:
  title: Blog
  path: /
nav:
  title: Blog
  path: /blog
  order: 3
time: 2019-12-25
---

After a long period of development (deferred), Pro's black theme, and the new theme switching program were officially launched. A picture is worth a thousand words, look at the picture directly.

Use [documentation] in detail (/docs/dynamic-theme)

![image](https://gw.alipayobjects.com/zos/antfincdn/raCkHezMns/Kapture%2525202019-11-25%252520at%25252019.15.12.gif)
